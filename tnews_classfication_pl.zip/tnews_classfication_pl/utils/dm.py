import argparse
import pytorch_lightning as pl

from datasets import load_dataset
from torch.utils.data import DataLoader
from transformers import AutoTokenizer, DataCollatorWithPadding


class TNewsDataModule(pl.LightningDataModule):
    def __init__(self, args, **kwargs):
        super().__init__()
        for k, v in kwargs.items():
            setattr(args, k, v)
        self.args = args
        self.tokenizer = AutoTokenizer.from_pretrained(
            self.args.model_name_or_path)

    def prepare_data(self):
        model_type = self.args.model_name_or_path.split("/")[-1]

        raw_datasets = load_dataset(
            "utils/custom_dataset.py", "tnews", cache_dir="cache")

        def preprocess_function(example):
            result = self.tokenizer(example["sentence"], example["keywords"],
                                    padding=self.args.padding, max_length=self.args.max_length, truncation=True)
            result["labels"] = example["label"]
            return result

        self.processed_datasets = raw_datasets.map(
            preprocess_function,
            batched=True,
            remove_columns=raw_datasets["train"].column_names,
            cache_file_names={
                "train": f"{self.args.cached_dir}/tnews-cached-tokenized-train-{self.args.max_length}-{model_type}.arrow", "validation": f"{self.args.cached_dir}/tnews-cached-tokenized-validation-{self.args.max_length}-{model_type}.arrow"},
            desc="Running tokenizer on dataset",
        )
        self.processed_datasets.set_format(type='torch', columns=[
            'input_ids', 'token_type_ids', 'attention_mask', 'labels'])
        self.num_labels = len(raw_datasets["train"].features["label"].names)

    def setup(self, stage=None):
        if stage == 'fit' or stage is None:
            self.train_ds = self.processed_datasets["train"]
            self.dev_ds = self.processed_datasets["validation"]

        else:
            self.dev_ds = self.processed_datasets["validation"]

    @property
    def collate_fn(self):
        return DataCollatorWithPadding(self.tokenizer)

    def train_dataloader(self):
        return DataLoader(dataset=self.train_ds,
                          batch_size=self.args.train_batch_size,
                          num_workers=self.args.num_workers,
                          collate_fn=self.collate_fn)

    def val_dataloader(self):
        return DataLoader(dataset=self.dev_ds,
                          batch_size=self.args.eval_batch_size,
                          num_workers=self.args.num_workers,
                          collate_fn=self.collate_fn)

    @staticmethod
    def add_dataset_specific_args(parent_parser):
        parser = argparse.ArgumentParser(parents=[parent_parser],
                                         add_help=False)
        parser.add_argument("--max_length",
                            type=int,
                            default=256,
                            help="max length of dataset")
        parser.add_argument("--cached_dir",
                            type=str,
                            default="data")
        parser.add_argument("--padding", action='store_true')
        parser.add_argument("--train_batch_size", default=8, type=int)
        parser.add_argument("--eval_batch_size", default=32, type=int)
        parser.add_argument("--num_workers", default=0, type=int)

        return parser


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="TNewsDataModule")
    parser = TNewsDataModule.add_dataset_specific_args(parser)
    args = parser.parse_args()

    dm = TNewsDataModule(args, model_name_or_path="bert-base-chinese")
    dm.prepare_data()
    dm.setup(stage='fit')

    # train
    for batch in dm.train_dataloader():
        for k, v in batch.items():
            print(k, v.shape)
        break

    # val
    for batch in dm.val_dataloader():
        for k, v in batch.items():
            print(k, v.shape)
        break
