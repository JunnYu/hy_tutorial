import argparse
import pytorch_lightning as pl

from pathlib import Path
from pytorch_lightning.callbacks import ModelCheckpoint
from data import TextClassificationDataModule
from model import TextClassificationTransformer


def get_parser():
    parser = argparse.ArgumentParser(description="Training Args")
    parser.add_argument("--pretrained_model_name_or_path",
                        default="bert-base-chinese",
                        type=str,
                        help="pretrained_model_name_or_path")
    parser.add_argument("--seed", default=42, type=int, help="random seed")
    parser.add_argument("--scheduler_type",
                        choices=[
                            "linear", "cosine", "cosine_with_restarts",
                            "polynomial", "constant", "constant_with_warmup"
                        ],
                        default="linear",
                        help="scheduler type")
    parser.add_argument("--lr", type=float, default=3e-5, help="learning rate")
    parser.add_argument("--weight_decay",
                        default=0.02,
                        type=float,
                        help="Weight decay if we apply some")
    parser.add_argument("--num_training_steps",
                        default=-1,
                        type=int,
                        help="Total training steps")

    parser.add_argument("--num_warmup_steps",
                        default=0.,
                        type=float,
                        help="Total warmup steps.")

    parser.add_argument("--adam_epsilon",
                        default=1e-8,
                        type=float,
                        help="Epsilon for Adam optimizer")

    return parser


def main():
    parser = get_parser()
    parser = TextClassificationDataModule.add_dataset_specific_args(parser)
    parser = pl.Trainer.add_argparse_args(parser)
    cfg = parser.parse_args()
    # parents：如果父目录不存在，是否创建父目录。
    # exist_ok：只有在目录不存在时创建目录，目录已存在时不会抛出异常。
    Path(cfg.cached_dir).mkdir(parents=True, exist_ok=True)
    # seed
    pl.seed_everything(cfg.seed)

    # callback
    ckpt_callback = ModelCheckpoint(
        filename='{epoch}-{step}-{val_accuracy:.4f}',
        monitor='val_accuracy',
        mode="max",
        save_top_k=5,
        save_weights_only=True)
    # dm
    tnews_dm = TextClassificationDataModule(cfg)
    tnews_dm.setup()
    # model
    model = TextClassificationTransformer(cfg, **tnews_dm.model_data_kwargs)

    trainer = pl.Trainer.from_argparse_args(cfg, callbacks=[ckpt_callback])
    trainer.fit(model=model, datamodule=tnews_dm)


if __name__ == '__main__':
    main()
