import os
import json
import datasets

_CITATION = "None"

_DESCRIPTION = "None"

_HOMEPAGE = "None"

_LICENSE = "MIT"

_URLs = {
    "tnews":
    "https://storage.googleapis.com/cluebenchmark/tasks/tnews_public.zip"
}

_LABELS_MAP = {
    '100': 'news_story',
    '101': 'news_culture',
    '102': 'news_entertainment',
    '103': 'news_sports',
    '104': 'news_finance',
    '106': 'news_house',
    '107': 'news_car',
    '108': 'news_edu',
    '109': 'news_tech',
    '110': 'news_military',
    '112': 'news_travel',
    '113': 'news_world',
    '114': 'news_stock',
    '115': 'news_agriculture',
    '116': 'news_game'
}


class Tnews(datasets.GeneratorBasedBuilder):
    """Tnews"""

    VERSION = datasets.Version("1.0.0")

    BUILDER_CONFIGS = [
        datasets.BuilderConfig(name="tnews",
                               version=VERSION,
                               description="Tnews"),
    ]

    DEFAULT_CONFIG_NAME = "tnews"

    def _info(self):
        features = datasets.Features({
            "sentence":
            datasets.Value("string"),
            "keywords":
            datasets.Value("string"),
            "label":
            datasets.ClassLabel(names=[
                'news_story', 'news_culture', 'news_entertainment',
                'news_sports', 'news_finance', 'news_house', 'news_car',
                'news_edu', 'news_tech', 'news_military', 'news_travel',
                'news_world', 'news_stock', 'news_agriculture', 'news_game'
            ])
        })
        return datasets.DatasetInfo(
            # This is the description that will appear on the datasets page.
            description=_DESCRIPTION,
            # This defines the different columns of the dataset and their types
            # Here we define them above because they are different between the two configurations
            features=features,
            # If there's a common (input, target) tuple from the features,
            # specify them here. They'll be used if as_supervised=True in
            # builder.as_dataset.
            supervised_keys=None,
            # Homepage of the dataset for documentation
            homepage=_HOMEPAGE,
            # License for the dataset if available
            license=_LICENSE,
            # Citation for the dataset
            citation=_CITATION,
        )

    def _split_generators(self, dl_manager):
        """Returns SplitGenerators."""
        my_urls = _URLs[self.config.name]
        data_dir = dl_manager.download_and_extract(my_urls)
        outputs = [
            datasets.SplitGenerator(
                name=datasets.Split.TRAIN,
                # These kwargs will be passed to _generate_examples
                gen_kwargs={
                    "filepath": os.path.join(data_dir, "train.json"),
                    "split": "train",
                },
            ),
            datasets.SplitGenerator(
                name=datasets.Split.VALIDATION,
                # These kwargs will be passed to _generate_examples
                gen_kwargs={
                    "filepath": os.path.join(data_dir, "dev.json"),
                    "split": "dev",
                },
            ),
        ]

        return outputs

    def _generate_examples(
            # method parameters are unpacked from `gen_kwargs` as given in `_split_generators`
            self,
            filepath,
            split):
        """Yields examples as (key, example) tuples."""
        with open(filepath, "r", encoding="utf8") as f:
            for _id, line in enumerate(f):
                line = json.loads(line)
                yield _id, {
                    "sentence": line["sentence"],
                    "keywords": line["keywords"],
                    "label": _LABELS_MAP[line["label"]],
                }
