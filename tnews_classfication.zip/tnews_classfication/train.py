import pandas as pd
from sklearn.metrics import accuracy_score
from simpletransformers.classification import ClassificationModel
# 读取tsv文件
train_df = pd.read_csv("dataset/processed/train.tsv", sep="\t")
eval_df = pd.read_csv("dataset/processed/dev.tsv", sep="\t")
# 定义label
label_list = ['news_story',
              'news_culture',
              'news_entertainment',
              'news_sports',
              'news_finance',
              'news_house',
              'news_car',
              'news_edu',
              'news_tech',
              'news_military',
              'news_travel',
              'news_world',
              'news_stock',
              'news_agriculture',
              'news_game']

model = ClassificationModel(
    model_type="bert",
    model_name="hfl/chinese-roberta-wwm-ext",
    num_labels=15,
    args={
        "reprocess_input_data": True,
        "overwrite_output_dir": True,
        "use_cached_eval_features": True,
        "do_lower_case": True,
        "evaluate_during_training": True,
        "labels_list": label_list,
        "max_seq_length": 256,
        "manual_seed": 42,
        "num_train_epochs": 10,
        "train_batch_size": 64,
        "eval_batch_size": 128,
        "save_optimizer_and_scheduler": False
    }
)

# 训练模型
model.train_model(train_df=train_df, eval_df=eval_df,
                  accuracy=accuracy_score)

# 评估模型
result, model_outputs, wrong_predictions = model.eval_model(
    eval_df,  accuracy=accuracy_score)
print(result)
