export TOKENIZERS_PARALLELISM=false
python train.py \
    --gpus=1 \
    --default_root_dir /tf_logs/ \
    --model_name_or_path hfl/chinese-roberta-wwm-ext \
    --lr 3e-5 \
    --scheduler linear \
    --warmup_prob 0.15 \
    --max_epochs 5 \
    --max_length 256 \
    --train_batch_size 64 \
    --eval_batch_size 128 \
    --num_workers 6 \
    --gradient_clip_val 5.0 \
    --seed 42 \
    --precision 16
