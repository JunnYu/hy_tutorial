# Copyright The PyTorch Lightning team.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
import os
import argparse
import pytorch_lightning as pl

from typing import Any, Dict, Optional, Union, Callable, List
from torch.utils.data import DataLoader
from datasets import Dataset, DatasetDict, load_dataset
from transformers import AutoTokenizer, DataCollatorWithPadding


class HFDataModule(pl.LightningDataModule):
    def __init__(self, cfg, **kwargs) -> None:
        super().__init__()
        for k, v in kwargs.items():
            setattr(cfg, k, v)
        os.environ["TOKENIZERS_PARALLELISM"] = "TRUE"
        self.cfg = cfg
        self.tokenizer = AutoTokenizer.from_pretrained(
            self.cfg.pretrained_model_name_or_path, use_fast=self.cfg.use_fast)
        self.model_type = self.cfg.pretrained_model_name_or_path.split(
            "/")[-1].replace("-", "_")

    def setup(self, stage: Optional[str] = None):
        dataset = self.load_dataset()
        dataset = self.split_dataset(dataset)
        dataset = self.process_data(dataset, stage=stage)
        self.ds = dataset

    def load_dataset(self) -> Dataset:
        # Allow custom data files when loading the dataset
        data_files = {}
        if self.cfg.train_file is not None:
            data_files["train"] = self.cfg.train_file
        if self.cfg.validation_file is not None:
            data_files["validation"] = self.cfg.validation_file
        if self.cfg.test_file is not None:
            data_files["test_file"] = self.cfg.test_file

        data_files = data_files if data_files else None
        if self.cfg.dataset_name is not None:
            # Download and load the Huggingface dataset.
            return load_dataset(path=self.cfg.dataset_name,
                                name=self.cfg.dataset_config_name,
                                cache_dir=self.cfg.cache_dir,
                                data_files=data_files)

        # Load straight from data files
        if not data_files:
            raise Exception(
                "You have not specified a dataset name. A custom train and validation file is required"
            )
        extension = self.cfg.train_file.split(".")[-1]
        return load_dataset(extension,
                            data_files=data_files,
                            cache_dir=self.cfg.cache_dir)

    def split_dataset(
            self, dataset: Union[Dataset,
                                 DatasetDict]) -> Union[Dataset, DatasetDict]:
        if self.cfg.train_val_split is not None:
            split = dataset["train"].train_test_split(self.cfg.train_val_split)
            dataset["train"] = split["train"]
            dataset["validation"] = split["test"]
        dataset = self._select_samples(dataset)
        return dataset

    def _select_samples(
            self, dataset: Union[Dataset,
                                 DatasetDict]) -> Union[Dataset, DatasetDict]:
        samples = (("train", self.cfg.limit_train_samples),
                   ("validation", self.cfg.limit_val_samples),
                   ("test", self.cfg.limit_test_samples))
        for column_name, n_samples in samples:
            if n_samples is not None and column_name in dataset:
                indices = range(min(len(dataset[column_name]), n_samples))
                dataset[column_name] = dataset[column_name].select(indices)
        return dataset

    def process_data(
            self,
            dataset: Union[Dataset, DatasetDict],
            stage: Optional[str] = None) -> Union[Dataset, DatasetDict]:
        return dataset

    def train_dataloader(self) -> DataLoader:
        return DataLoader(
            self.ds["train"],
            batch_size=self.cfg.train_batch_size,
            num_workers=self.cfg.num_workers,
            collate_fn=self.collate_fn,
        )

    def val_dataloader(self) -> DataLoader:
        return DataLoader(
            self.ds["validation"],
            batch_size=self.cfg.eval_batch_size,
            num_workers=self.cfg.num_workers,
            collate_fn=self.collate_fn,
        )

    def test_dataloader(self) -> Optional[DataLoader]:
        if "test" in self.ds:
            return DataLoader(
                self.ds["test"],
                batch_size=self.cfg.eval_batch_size,
                num_workers=self.cfg.num_workers,
                collate_fn=self.collate_fn,
            )

    @property
    def collate_fn(self) -> Optional[Callable]:
        return DataCollatorWithPadding(self.tokenizer)

    @property
    def model_data_kwargs(self) -> Dict:
        """
        Override to provide the model with additional kwargs.
        This is useful to provide the number of classes/pixels to the model or any other data specific args
        Returns: Dict of args
        """
        return {}

    @staticmethod
    def add_dataset_specific_args(parent_parser):
        parser = argparse.ArgumentParser(parents=[parent_parser],
                                         add_help=False)
        # datasets
        parser.add_argument("--dataset_name", type=str, default="custom_ds.py")
        parser.add_argument("--dataset_config_name", type=str, default="tnews")
        # download cache
        parser.add_argument("--cache_dir", type=str, default="caches")
        # features cache
        parser.add_argument("--cached_dir", type=str, default="features")

        # tokenizer
        parser.add_argument("--use_fast", action='store_true')
        parser.add_argument("--max_length", type=int, default=256)
        parser.add_argument("--padding", action='store_true')
        parser.add_argument("--truncation", action='store_true')
        # dataloader
        parser.add_argument("--train_batch_size", type=int, default=8)
        parser.add_argument("--eval_batch_size", type=int, default=32)
        parser.add_argument("--num_workers", type=int, default=0)

        # custom data file
        parser.add_argument("--train_file", type=str, default=None)
        parser.add_argument("--validation_file", type=str, default=None)
        parser.add_argument("--test_file", type=str, default=None)
        parser.add_argument("--limit_train_samples", type=int, default=None)
        parser.add_argument("--limit_val_samples", type=int, default=None)
        parser.add_argument("--limit_test_samples", type=int, default=None)
        parser.add_argument("--train_val_split", type=float, default=None)
        return parser


class TextClassificationDataModule(HFDataModule):
    def process_data(self,
                     dataset: Dataset,
                     stage: Optional[str] = None) -> Dataset:
        input_feature_fields = [
            k for k, v in dataset["train"].features.items()
            if k not in ["label"]
        ]

        dataset = self.preprocess(
            dataset,
            tokenizer=self.tokenizer,
            input_feature_fields=input_feature_fields,
            padding=self.cfg.padding,
            truncation=self.cfg.truncation,
            max_length=self.cfg.max_length,
        )
        cols_to_keep = [
            x for x in
            ["input_ids", "attention_mask", "token_type_ids", "labels"]
            if x in dataset["train"].features
        ]
        dataset.set_format("torch", columns=cols_to_keep)
        self.labels = dataset["train"].features["labels"]
        return dataset

    @staticmethod
    def convert_to_features(example_batch: Any, tokenizer,
                            input_feature_fields: List[str],
                            **tokenizer_kwargs):
        # Either encode single sentence or sentence pairs
        if len(input_feature_fields) > 1:
            texts_or_text_pairs = list(
                zip(example_batch[input_feature_fields[0]],
                    example_batch[input_feature_fields[1]]))
        else:
            texts_or_text_pairs = example_batch[input_feature_fields[0]]
        # Tokenize the text/text pairs
        return tokenizer(texts_or_text_pairs, **tokenizer_kwargs)

    def preprocess(self, ds: Dataset, **fn_kwargs) -> Dataset:
        ds = ds.map(
            # todo: change this to self.convert_to_features for users to override
            TextClassificationDataModule.convert_to_features,
            batched=True,
            cache_file_names={
                "train":
                f"{self.cfg.cached_dir}/tnews-cached-tokenized-train-{self.cfg.max_length}-{self.model_type}.arrow",
                "validation":
                f"{self.cfg.cached_dir}/tnews-cached-tokenized-validation-{self.cfg.max_length}-{self.model_type}.arrow"
            },
            desc="Running convert_to_features on dataset.",
            # fn_kwargs
            fn_kwargs=fn_kwargs,
        )
        ds = ds.rename_column("label", "labels")
        return ds

    @property
    def num_labels(self) -> int:
        return self.labels.num_classes

    @property
    def model_data_kwargs(self) -> Dict[str, int]:
        return {"num_labels": self.num_labels}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="TextClassificationDataModule")
    parser = TextClassificationDataModule.add_dataset_specific_args(parser)
    cfg = parser.parse_args()
    cfg.pretrained_model_name_or_path = "bert-base-chinese"
    dm = TextClassificationDataModule(cfg)
    dm.setup()
    # train
    for batch in dm.train_dataloader():
        for k, v in batch.items():
            print(k, v.shape)
        break

    # val
    for batch in dm.val_dataloader():
        for k, v in batch.items():
            print(k, v.shape)
        break
