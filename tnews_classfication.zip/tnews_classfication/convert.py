import json
import pandas as pd
from fastcore.foundation import L


def convert(path):
    all_data = []
    with open(path, "r", encoding="utf8") as f:
        lines = f.readlines()
        for line in lines:
            data = json.loads(line)
            all_data.append(data)
    labels = L(all_data).attrgot("label_desc")
    text_a = L(all_data).attrgot("keywords").map(
        lambda x: "空" if len(x) == 0 else x)
    text_b = L(all_data).attrgot("sentence").map(
        lambda x: "空" if len(x) == 0 else x)
    max_length = max(L(all_data).map(
        lambda x: len(x["keywords"]+x["sentence"])))
    df = pd.DataFrame({"text_a": text_a, "text_b": text_b, "labels": labels})
    if "train" in path:
        df.to_csv("dataset/processed/train.tsv", sep="\t", index=False)
        print("train maxlen ", max_length)
    else:
        df.to_csv("dataset/processed/dev.tsv", sep="\t", index=False)
        print("dev maxlen ", max_length)


if __name__ == "__main__":
    # train maxlen 182
    convert("dataset/raw/train.json")

    # dev maxlen 157
    convert("dataset/raw/dev.json")
