import pytorch_lightning as pl
from train import TNewsModel
from utils.dm import TNewsDataModule


def validate(ckpt, hparams_file):
    trainer = pl.Trainer(gpus=1, logger=False)
    model = TNewsModel.load_from_checkpoint(checkpoint_path=ckpt,
                                            hparams_file=hparams_file)
    dm = TNewsDataModule(model.hparams)
    trainer.validate(model=model, datamodule=dm)


if __name__ == '__main__':
    CHECKPOINTS = "outputs/lightning_logs/version_0/checkpoints/epoch=0-step=6669-val_acc=0.6467.ckpt"
    HPARAMS = "outputs/lightning_logs/version_0/hparams.yaml"
    validate(ckpt=CHECKPOINTS, hparams_file=HPARAMS)
