export PRETRAINED_MODEL=bert-base-chinese

python fire.py \
    --gpus=1 \
    --default_root_dir /tf_logs/ \
    --pretrained_model_name_or_path $PRETRAINED_MODEL \
    --dataset_name custom_ds.py \
    --dataset_config_name tnews \
    --use_fast \
    --truncation \
    --lr 3e-5 \
    --scheduler_type linear \
    --num_warmup_steps 0.15 \
    --max_epochs 5 \
    --max_length 256 \
    --train_batch_size 64 \
    --eval_batch_size 128 \
    --num_workers 6 \
    --gradient_clip_val 5.0 \
    --seed 42 \
    --precision 16