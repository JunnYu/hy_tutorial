# Copyright The PyTorch Lightning team.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import torch
import pytorch_lightning as pl

from typing import Any, Dict, Union, Tuple
from torchmetrics import Accuracy, Precision, Recall, F1, MetricCollection
from transformers import AutoModelForSequenceClassification, AdamW, get_scheduler


class TextClassificationTransformer(pl.LightningModule):
    def __init__(self, cfg, **model_data_kwargs) -> None:
        super().__init__()
        for k, v in model_data_kwargs.items():
            setattr(cfg, k, v)
        self.save_hyperparameters(cfg)
        self.model = AutoModelForSequenceClassification.from_pretrained(
            self.hparams.pretrained_model_name_or_path, **model_data_kwargs)

    def common_step(self, prefix: str, batch: Any) -> torch.Tensor:
        outputs = self.model(**batch)
        loss, logits = outputs[:2]
        preds = torch.argmax(logits, dim=-1)
        metric_dict = self.compute_metrics(preds, batch["labels"])
        self.log_dict(metric_dict, prog_bar=True, on_step=False, on_epoch=True)
        self.log(f"{prefix}_loss", loss, prog_bar=True, sync_dist=True)
        return loss

    def training_step(self, batch: Any, batch_idx: int) -> torch.Tensor:
        outputs = self.model(**batch)
        loss = outputs[0]
        self.log("lr",
                 self.trainer.lr_schedulers[0]["scheduler"].get_last_lr()[-1],
                 prog_bar=True)
        self.log("train_loss", loss)
        return loss

    def validation_step(self,
                        batch: Any,
                        batch_idx: int,
                        dataloader_idx: int = 0) -> torch.Tensor:
        return self.common_step("val", batch)

    def test_step(self,
                  batch: Any,
                  batch_idx: int,
                  dataloader_idx: int = 0) -> torch.Tensor:
        return self.common_step("test", batch)

    # setup metrics
    def setup(self, stage: str):
        self.configure_metrics(stage)

    def configure_metrics(self, stage) -> None:
        prefix = "val_" if stage == "fit" else "test_"
        self.metric_collection = MetricCollection(
            {
                "accuracy": Accuracy(),
                # "f1": F1(num_classes=self.num_labels),
                # "precision": Precision(num_classes=self.num_labels),
                # "recall": Recall(num_classes=self.num_labels)
            },
            prefix=prefix)

    def compute_metrics(self, preds, labels) -> Dict[str, torch.Tensor]:
        # preds = preds[labels != -100]
        # labels = labels[labels != -100]
        return self.metric_collection(preds, labels)

    # configure optimizer
    def configure_optimizers(self) -> Dict:
        no_decay = ["bias", "LayerNorm.weight"]
        optimizer_grouped_parameters = [
            {
                "params": [
                    p for n, p in self.model.named_parameters()
                    if not any(nd in n for nd in no_decay)
                ],
                "weight_decay":
                self.hparams.weight_decay,
            },
            {
                "params": [
                    p for n, p in self.model.named_parameters()
                    if any(nd in n for nd in no_decay)
                ],
                "weight_decay":
                0.0,
            },
        ]
        # compute_warmup
        num_training_steps, num_warmup_steps = self.compute_warmup(
            num_training_steps=self.hparams.num_training_steps,
            num_warmup_steps=self.hparams.num_warmup_steps,
        )
        self.optimizer = AdamW(optimizer_grouped_parameters,
                               lr=self.hparams.lr,
                               eps=self.hparams.adam_epsilon)

        self.scheduler = get_scheduler(self.hparams.scheduler_type,
                                       optimizer=self.optimizer,
                                       num_warmup_steps=num_warmup_steps,
                                       num_training_steps=num_training_steps)

        return {
            "optimizer": self.optimizer,
            "lr_scheduler": {
                "scheduler": self.scheduler,
                "interval": "step",
                "frequency": 1
            },
        }

    def compute_warmup(
            self,
            num_training_steps: int = -1,
            num_warmup_steps: Union[int, float] = 0) -> Tuple[int, int]:
        if num_training_steps < 0:
            # less than 0 specifies to infer number of training steps
            num_training_steps = self.num_training_steps
        if isinstance(num_warmup_steps, float):
            # Convert float values to percentage of training steps to use as warmup
            num_warmup_steps *= num_training_steps
        return num_training_steps, num_warmup_steps

    @property
    def num_training_steps(self) -> int:
        """Total training steps inferred from datamodule and devices."""
        if isinstance(self.trainer.limit_train_batches,
                      int) and self.trainer.limit_train_batches != 0:
            dataset_size = self.trainer.limit_train_batches
        elif isinstance(self.trainer.limit_train_batches, float):
            # limit_train_batches is a percentage of batches
            dataset_size = len(self.trainer.datamodule.train_dataloader())
            dataset_size = int(dataset_size * self.trainer.limit_train_batches)
        else:
            dataset_size = len(self.trainer.datamodule.train_dataloader())

        num_devices = max(1, self.trainer.num_gpus, self.trainer.num_processes)
        if self.trainer.tpu_cores:
            num_devices = max(num_devices, self.trainer.tpu_cores)

        effective_batch_size = self.trainer.accumulate_grad_batches * num_devices
        max_estimated_steps = (dataset_size //
                               effective_batch_size) * self.trainer.max_epochs

        if self.trainer.max_steps and self.trainer.max_steps < max_estimated_steps:
            return self.trainer.max_steps
        return max_estimated_steps

    @property
    def num_labels(self) -> int:
        return self.trainer.datamodule.num_labels

    @property
    def task_type(self) -> str:
        return "classification"
