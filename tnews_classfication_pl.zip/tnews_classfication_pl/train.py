import argparse
import pytorch_lightning as pl

from torchmetrics import Accuracy
from utils.dm import TNewsDataModule
from pytorch_lightning.callbacks import ModelCheckpoint
from transformers import (AutoModelForSequenceClassification, AdamW, get_linear_schedule_with_warmup,
                          get_cosine_schedule_with_warmup, get_polynomial_decay_schedule_with_warmup)

arg_to_scheduler = {
    "linear": get_linear_schedule_with_warmup,
    "cosine": get_cosine_schedule_with_warmup,
    "polynomial": get_polynomial_decay_schedule_with_warmup,
}


class TNewsModel(pl.LightningModule):
    def __init__(self, args, **kwargs):
        super().__init__()
        for k, v in kwargs.items():
            setattr(args, k, v)
        self.save_hyperparameters(args)
        self.model = AutoModelForSequenceClassification.from_pretrained(
            self.hparams.model_name_or_path, num_labels=self.hparams.num_labels)
        self.accuracy = Accuracy()

    @property
    def num_training_steps(self):
        # copy from https://github.com/PyTorchLightning/lightning-transformers/blob/1c5c91f5b4962f9162bcbd41fee7a7ac5eae00a9/lightning_transformers/core/model.py#L56
        """Total training steps inferred from datamodule and devices."""
        if isinstance(self.trainer.limit_train_batches, int) and self.trainer.limit_train_batches != 0:
            dataset_size = self.trainer.limit_train_batches
        elif isinstance(self.trainer.limit_train_batches, float):
            dataset_size = len(self.trainer.datamodule.train_dataloader())
            dataset_size = int(dataset_size * self.trainer.limit_train_batches)
        else:
            dataset_size = len(self.trainer.datamodule.train_dataloader())

        num_devices = max(1, self.trainer.num_gpus, self.trainer.num_processes)
        if self.trainer.tpu_cores:
            num_devices = max(num_devices, self.trainer.tpu_cores)

        effective_batch_size = self.trainer.accumulate_grad_batches * num_devices
        max_estimated_steps = (
            dataset_size // effective_batch_size) * self.trainer.max_epochs

        if self.trainer.max_steps and self.trainer.max_steps < max_estimated_steps:
            return self.trainer.max_steps
        return max_estimated_steps

    def configure_optimizers(self):
        no_decay = ["bias", "LayerNorm.weight"]
        optimizer_grouped_parameters = [
            {
                "params": [
                    p for n, p in self.model.named_parameters()
                    if not any(nd in n for nd in no_decay)
                ],
                "weight_decay":
                self.hparams.weight_decay,
            },
            {
                "params": [
                    p for n, p in self.model.named_parameters()
                    if any(nd in n for nd in no_decay)
                ],
                "weight_decay":
                0.0,
            },
        ]

        optimizer = AdamW(optimizer_grouped_parameters,
                          lr=self.hparams.lr,
                          eps=self.hparams.adam_epsilon)

        scheduler = arg_to_scheduler[self.hparams.scheduler](
            optimizer,
            num_warmup_steps=int(self.num_training_steps *
                                 self.hparams.warmup_prob),
            num_training_steps=self.num_training_steps)
        scheduler = {
            "scheduler": scheduler,
            "interval": "step",
            "frequency": 1
        }

        return [optimizer], [scheduler]

    def forward(self,
                input_ids=None,
                token_type_ids=None,
                attention_mask=None,
                labels=None):
        return self.model(input_ids,
                          token_type_ids=token_type_ids,
                          attention_mask=attention_mask,
                          labels=labels)

    def training_step(self, batch, batch_idx):
        outputs = self(**batch)
        self.log("lr",
                 self.trainer.lr_schedulers[0]["scheduler"].get_last_lr()[-1],
                 prog_bar=True)
        self.log("train_loss", outputs.loss)
        return outputs.loss

    def validation_step(self, batch, batch_idx):
        outputs = self(**batch)
        preds = outputs.logits.argmax(dim=-1)
        self.accuracy(preds, batch["labels"])
        self.log("val_loss", outputs.loss, prog_bar=True)

    def on_validation_epoch_start(self):
        self.accuracy.reset()

    def on_validation_epoch_end(self):
        acc = self.accuracy.compute()
        self.log('val_acc', acc, prog_bar=True)


def get_parser():
    parser = argparse.ArgumentParser(description="Training Args")
    parser.add_argument("--model_name_or_path",
                        default="bert-base-chinese",
                        type=str,
                        help="model_name_or_path")
    parser.add_argument("--seed", default=42, type=int, help="random seed")
    parser.add_argument("--scheduler",
                        choices=["linear", "cosine", "polynomial"],
                        default="linear",
                        help="scheduler type")
    parser.add_argument("--lr", type=float, default=3e-5, help="learning rate")
    parser.add_argument("--weight_decay",
                        default=0.02,
                        type=float,
                        help="Weight decay if we apply some")
    parser.add_argument("--warmup_prob",
                        default=0.,
                        type=float,
                        help="Warmup steps used for scheduler")
    parser.add_argument("--adam_epsilon",
                        default=1e-8,
                        type=float,
                        help="Epsilon for Adam optimizer")

    return parser


def main():
    parser = get_parser()
    parser = TNewsDataModule.add_dataset_specific_args(parser)
    parser = pl.Trainer.add_argparse_args(parser)
    args = parser.parse_args()

    # seed
    pl.seed_everything(args.seed)

    # callback
    ckpt_callback = ModelCheckpoint(filename='{epoch}-{step}-{val_acc:.4f}',
                                    monitor='val_acc',
                                    mode="max",
                                    save_top_k=5,
                                    save_weights_only=True)
    # dm
    tnews_dm = TNewsDataModule(args)
    tnews_dm.prepare_data()
    args.num_labels = tnews_dm.num_labels

    # model
    model = TNewsModel(args)

    trainer = pl.Trainer.from_argparse_args(args, callbacks=[ckpt_callback])
    trainer.fit(model=model, datamodule=tnews_dm)


if __name__ == '__main__':
    main()
