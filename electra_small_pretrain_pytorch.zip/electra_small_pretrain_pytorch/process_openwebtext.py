from hugdatafast import *
from _utils.utils import *
from _utils.would_like_to_pr import *
from transformers import ElectraTokenizerFast
c = MyConfig({
    'size': 'small',
    'datas': ['openwebtext'],
})
i = ['small', 'base', 'large'].index(c.size)
c.max_length = [128, 512, 512][i]
hf_tokenizer = ElectraTokenizerFast.from_pretrained(
    f"google/electra-{c.size}-generator")
ELECTRAProcessor = partial(
    ELECTRADataProcessor, hf_tokenizer=hf_tokenizer, max_length=c.max_length)

if 'openwebtext' in c.datas:
    print('load/download OpenWebText Corpus')
    owt = datasets.load_dataset(
        './openwebtext.py', cache_dir='/hy-tmp')['train']
    print('load/create data from OpenWebText Corpus for ELECTRA')
    e_owt = ELECTRAProcessor(owt, apply_cleaning=False).map(
        cache_file_name=f"electra_owt_{c.max_length}.arrow", num_proc=1)

print("process done!")
